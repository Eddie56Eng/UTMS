package vehicle;

import vehicles.interfaces.*;

public class Van extends vehicle implements Serviceable, Trackable, Schedulable {
    public Van(String id) {
        super(id, "Bus");
    }
    
    @Override
    public void service() {
        System.out.println("van " + getVehicleID() + " has been serviced.");
    }
    
    @Override
    public String track() {
        return "van " + getVehicleID() + " is on Route A.";
    }

    @Override
    public void schedule(String route, String time) {
        System.out.println("Van scheduled to " + route + " at " + time);
    }

    @Override
    public void displayDetails() {
        System.out.println("Vehicle ID: " + getVehicleID() + ", Type: " + getType());
    }
}

