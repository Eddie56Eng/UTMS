
package vehicle;

import vehicles.interfaces.*;

public class Bus extends vehicle implements Serviceable, Trackable, Schedulable {
    public Bus(String id) {
        super(id, "Bus");
    }
   
    @Override
    public void service() {
        System.out.println("Bus " + getVehicleID() + " has been serviced.");
    }
    
    @Override
    public String track() {
        return "Bus " + getVehicleID() + " is on Route A.";
    }
    
    @Override
    public void schedule(String route, String time) {
        System.out.println("Bus scheduled to " + route + " at " + time);
    }

    @Override
    public void displayDetails() {
        System.out.println("Vehicle ID: " + getVehicleID() + ", Type: " + getType());
    }
}

