package vehicle;

public abstract class vehicle {
    private String vehicleID;
    private String type;

    public vehicle(String vehicleID, String type) {
        this.vehicleID = vehicleID;
        this.type = type;
    }

    public String getVehicleID() { 
        return vehicleID; 
    }
    public String getType() { 
        return type; 
    }

    public abstract void displayDetails();
}

