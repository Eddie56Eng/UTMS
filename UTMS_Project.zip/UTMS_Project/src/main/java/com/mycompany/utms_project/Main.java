package com.mycompany.utms_project;

import users.*;
import vehicle.*;

public class Main {
    public static void main(String[] args) {
        // Users
        user s = new Student("S1", "Clark");
        user l = new Lecturer("L1", "Dr. Bazigu");
        user t = new TransportOfficer("T1", "Mr. James");

        s.requestTransport();
        l.requestTransport();
        t.requestTransport();

        System.out.println("-----");

        // Vehicles
        Bus bus = new Bus("B101");
        Van van = new Van("V202");

        bus.displayDetails();
        System.out.println(bus.track());
        bus.schedule("Campus", "8:00 AM");
        bus.service();

        System.out.println("-----");

        van.displayDetails();
        System.out.println(van.track());
        van.schedule("City", "10:00 AM");
        van.service();

        System.out.println("-----");

        // Overloaded Methods
        TransportService service = new TransportService();
        service.assignDriver("John", "Bus");
        service.assignDriver("Linda", "10:00 PM", true);
    }
}
