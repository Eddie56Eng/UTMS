/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.utms_project;

/**
 *
 * @author MATOVU
 */
public class UTMS_Project {

    public static void main(String[] args) {
        System.out.println("Main");
    }
}
