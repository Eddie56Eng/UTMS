package com.mycompany.utms_project;

public class TransportService {
    // Overload by vehicle type
    public void assignDriver(String driverName, String vehicleType) {
        System.out.println(driverName + " assigned to " + vehicleType);
    }

    // Overload by shift
    public void assignDriver(String driverName, String shiftTime, boolean isNight) {
        String shift = isNight ? "Night" : "Day";
        System.out.println(driverName + " assigned for " + shift + " shift at " + shiftTime);
    }
}

