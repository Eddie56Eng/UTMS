package users;

public class Student extends user {
    public Student(String id, String name) {
        super(id, name);
    }

    @Override
    public void requestTransport() {
        System.out.println("Student " + getName() + " requested transport.");
    }
}
