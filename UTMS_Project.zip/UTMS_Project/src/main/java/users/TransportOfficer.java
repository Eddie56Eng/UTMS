
package users;

public class TransportOfficer extends user {
    public TransportOfficer(String id, String name) {
        super(id, name);
    }

    @Override
    public void requestTransport() {
        System.out.println("Transport Officer " + getName() + " is scheduling transport.");
    }
}

