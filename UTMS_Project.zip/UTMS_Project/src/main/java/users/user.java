package users;

public abstract class user {
    private String id;
    private String name;

    public user(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() { return id; }
    public String getName() { return name; }

    // Abstract method (must be implemented by child classes)
    public abstract void requestTransport();
}
