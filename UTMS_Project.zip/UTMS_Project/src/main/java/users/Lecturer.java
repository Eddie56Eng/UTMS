package users;

public class Lecturer extends user {
    public Lecturer(String id, String name) {
        super(id, name);
    }

    @Override
    public void requestTransport() {
        System.out.println("Lecturer " + getName() + " requested academic transport.");
    }
}

