package vehicles.interfaces;

public interface Schedulable {
    void schedule(String route, String time);
}
