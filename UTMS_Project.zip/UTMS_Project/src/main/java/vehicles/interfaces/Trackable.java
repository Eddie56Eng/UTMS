package vehicles.interfaces;

public interface Trackable {
    String track();
}
