package vehicles.interfaces;

public interface Serviceable {
    void service();
}

